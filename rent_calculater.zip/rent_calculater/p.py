import json
import datetime
import os
from typing import Dict, List, Optional

class ExpenseCalculator:
    def __init__(self):
        self.expense_history = []
        self.load_history()
    
    def calculate_expenses(self, rent: float, food: float, electricity_units: float, 
                         charge_per_unit: float, persons: int, additional_expenses: Dict = None) -> Dict:
        """
        Calculate shared expenses with enhanced features
        """
        try:
            # Input validation
            if persons < 1:                raise ValueError("Number of persons must be at least 1")
            
            if any(val < 0 for val in [rent, food, electricity_units, charge_per_unit]):
                raise ValueError("Expenses cannot be negative")
            
            # Calculate electricity cost
            total_electricity_charge = electricity_units * charge_per_unit
            
            # Calculate base expenses
            base_expenses = rent + food + total_electricity_charge
            
            # Add additional expenses if any
            additional_total = sum(additional_expenses.values()) if additional_expenses else 0
            total_expenses = base_expenses + additional_total
            
            # Calculate per person share
            per_person_share = total_expenses / persons
            
            # Prepare detailed breakdown
            breakdown = {
                'rent_per_person': rent / persons,
                'food_per_person': food / persons,
                'electricity_per_person': total_electricity_charge / persons,
                'additional_per_person': additional_total / persons if additional_total else 0
            }
            
            result = {
                'total_expenses': total_expenses,
                'per_person_share': per_person_share,
                'electricity_cost': total_electricity_charge,
                'breakdown': breakdown,
                'additional_expenses': additional_total,
                'timestamp': datetime.datetime.now().isoformat(),
                'persons': persons
            }
            
            # Save to history
            self.save_to_history(result)
            
            return result
            
        except Exception as e:
            return {'error': str(e)}
    
    def save_to_history(self, calculation: Dict):
        """Save calculation to history"""
        self.expense_history.append(calculation)
        self.save_history()
    
    def save_history(self):
        """Save history to file"""
        try:
            with open('expense_history.json', 'w') as f:
                json.dump(self.expense_history, f, indent=2)
        except:
            pass  # Silently fail if file operations don't work
    
    def load_history(self):
        """Load history from file"""
        try:
            if os.path.exists('expense_history.json'):
                with open('expense_history.json', 'r') as f:
                    self.expense_history = json.load(f)
        except:
            self.expense_history = []
    
    def get_history(self, limit: int = 10) -> List[Dict]:
        """Get recent calculation history"""
        return self.expense_history[-limit:]
    
    def calculate_multiple_months(self, monthly_data: List[Dict]) -> Dict:
        """Calculate expenses for multiple months"""
        try:
            total_per_person = 0
            monthly_breakdown = []
            
            for month_data in monthly_data:
                result = self.calculate_expenses(**month_data)
                if 'error' not in result:
                    total_per_person += result['per_person_share']
                    monthly_breakdown.append({
                        'month': month_data.get('month_name', 'Unknown'),
                        'amount': result['per_person_share'],
                        'details': result
                    })
            
            return {
                'total_per_person': total_per_person,
                'monthly_breakdown': monthly_breakdown,
                'average_per_month': total_per_person / len(monthly_data) if monthly_data else 0
            }
        except Exception as e:
            return {'error': str(e)}

def display_results(result: Dict):
    """Display results in a formatted way"""
    if 'error' in result:
        print(f"❌ Error: {result['error']}")
        return
    
    print("\n" + "="*50)
    print("💰 EXPENSE CALCULATION RESULTS")
    print("="*50)
    
    print(f"👥 Number of People: {result['persons']}")
    print(f"💡 Electricity Cost: ₹{result['electricity_cost']:,.2f}")
    print(f"📦 Additional Expenses: ₹{result.get('additional_expenses', 0):,.2f}")
    print(f"💰 Total Expenses: ₹{result['total_expenses']:,.2f}")
    print(f"🎯 Each Person Pays: ₹{result['per_person_share']:,.2f}")
    
    print("\n📊 Detailed Breakdown:")
    breakdown = result['breakdown']
    print(f"   🏠 Rent: ₹{breakdown['rent_per_person']:,.2f} per person")
    print(f"   🍔 Food: ₹{breakdown['food_per_person']:,.2f} per person")
    print(f"   ⚡ Electricity: ₹{breakdown['electricity_per_person']:,.2f} per person")
    
    if breakdown['additional_per_person'] > 0:
        print(f"   📝 Additional: ₹{breakdown['additional_per_person']:,.2f} per person")
    
    print("="*50)

def get_user_input():
    """Get user input with validation and additional options"""
    calculator = ExpenseCalculator()
    
    print("🏠 SMART EXPENSE CALCULATOR")
    print("Enter your monthly expenses:\n")
    
    try:
        # Basic expenses
        rent = float(input("🏠 Enter monthly rent: ₹"))
        food = float(input("🍔 Enter food expenses: ₹"))
        electricity_units = float(input("💡 Enter electricity units used: "))
        charge_per_unit = float(input("⚡ Enter charge per unit: ₹"))
        persons = int(input("👥 Enter number of people: "))
        
        # Additional expenses
        additional_expenses = {}
        print("\n💎 Additional Expenses (press Enter to skip):")
        
        additional_categories = [
            "Water Bill", "Internet", "Gas", "Maintenance", 
            "Cleaning", "Other Utilities"
        ]
        
        for category in additional_categories:
            try:
                amount = input(f"   {category}: ₹")
                if amount.strip():
                    additional_expenses[category] = float(amount)
            except ValueError:
                continue
        
        # Calculate and display results
        result = calculator.calculate_expenses(
            rent, food, electricity_units, charge_per_unit, 
            persons, additional_expenses
        )
        
        display_results(result)
        
        # Show history
        if input("\n📜 Show recent calculations? (y/n): ").lower() == 'y':
            history = calculator.get_history(5)
            if history:
                print("\nRecent Calculations:")
                for i, calc in enumerate(reversed(history), 1):
                    print(f"{i}. ₹{calc['per_person_share']:,.2f} per person")
        
    except ValueError as e:
        print(f"❌ Invalid input: Please enter valid numbers")
    except KeyboardInterrupt:
        print("\n👋 Goodbye!")
    except Exception as e:
        print(f"❌ An error occurred: {e}")

# Advanced features
def batch_calculation():
    """Calculate for multiple months"""
    calculator = ExpenseCalculator()
    months = []
    
    print("📅 MULTI-MONTH CALCULATION")
    
    while True:
        print(f"\nMonth {len(months) + 1}:")
        try:
            month_name = input("Month name (e.g., 'January 2024'): ")
            rent = float(input("Rent: ₹"))
            food = float(input("Food: ₹"))
            electricity = float(input("Electricity units: "))
            charge = float(input("Charge per unit: ₹"))
            persons = int(input("Number of people: "))
            
            months.append({
                'rent': rent,
                'food': food,
                'electricity_units': electricity,
                'charge_per_unit': charge,
                'persons': persons,
                'month_name': month_name
            })
            
            if input("Add another month? (y/n): ").lower() != 'y':
                break
                
        except ValueError:
            print("Invalid input, try again")
    
    if months:
        result = calculator.calculate_multiple_months(months)
        if 'error' not in result:
            print(f"\n📊 TOTAL FOR {len(months)} MONTHS: ₹{result['total_per_person']:,.2f}")
            print(f"📈 AVERAGE PER MONTH: ₹{result['average_per_month']:,.2f}")

# Example usage with different scenarios
def example_usage():
    """Show example usage"""
    calculator = ExpenseCalculator()
    
    print("🚀 EXAMPLE SCENARIOS")
    
    # Example 1: Basic calculation
    print("\n1. Basic Roommate Sharing:")
    result1 = calculator.calculate_expenses(
        rent=15000, food=8000, electricity_units=200, 
        charge_per_unit=8, persons=3
    )
    display_results(result1)
    
    # Example 2: With additional expenses
    print("\n2. With Additional Expenses:")
    additional = {'Internet': 1000, 'Water': 500, 'Maintenance': 1000}
    result2 = calculator.calculate_expenses(
        rent=18000, food=10000, electricity_units=250,
        charge_per_unit=8.5, persons=4, additional_expenses=additional
    )
    display_results(result2)

if __name__ == "__main__":
    print("Choose mode:")
    print("1. Single Calculation")
    print("2. Multi-Month Calculation") 
    print("3. See Examples")
    
    choice = input("Enter choice (1-3): ").strip()
    
    if choice == "1":
        get_user_input()
    elif choice == "2":
        batch_calculation()
    elif choice == "3":
        example_usage()
    else:
        get_user_input()  # Default to single calculation