import random
def get_computer_choice():
    choices = ['rock', 'paper', 'scissors']
    return random.choice(choices)

def determine_winner(user_choice, computer_choice):
    if user_choice == computer_choice:
        return 'tie'
    elif (user_choice == 'rock' and computer_choice == 'scissors') or \
         (user_choice == 'paper' and computer_choice == 'rock') or \
         (user_choice == 'scissors' and computer_choice == 'paper'):
        return 'user'
    else:
        return 'computer'

def play_rps(user_choice):
    computer_choice = get_computer_choice()
    winner = determine_winner(user_choice, computer_choice)
    return {
        'user_choice': user_choice,
        'computer_choice': computer_choice,
        'winner': winner
    }

if __name__ == "__main__":
    user_input = input("Enter rock, paper, or scissors: ").strip().lower()
    if user_input not in ['rock', 'paper', 'scissors']:
        print("Invalid choice. Please choose rock, paper, or scissors.")
    else:
        result = play_rps(user_input)
        print(f"You chose: {result['user_choice']}")
        print(f"Computer chose: {result['computer_choice']}")
        if result['winner'] == 'tie':
            print("It's a tie!")
        elif result['winner'] == 'user':
            print("You win!")
        else:
            print("Computer wins!")
            
